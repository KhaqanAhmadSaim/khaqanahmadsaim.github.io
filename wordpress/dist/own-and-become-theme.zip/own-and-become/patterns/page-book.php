<?php
/**
 * Title: Page: Book a free consult
 * Slug: own-and-become/page-book
 * Categories: own-and-become-pages
 * Post Types: page
 * Block Types: core/post-content
 *
 * @package own-and-become
 */
?>
<!-- wp:group {"metadata":{"name":"Page hero"},"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"tint","className":"ob-page-hero","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull ob-page-hero has-tint-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"style":{"spacing":{"blockGap":"1.1rem"}},"layout":{"type":"constrained","contentSize":"720px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"is-style-eyebrow"} -->
<p class="is-style-eyebrow">Book a free consult</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xx-large","level":1} -->
<h1 class="wp-block-heading has-xx-large-font-size">A gentle first step</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">A free, no-pressure 15-minute call to talk about what’s going on, ask questions and see whether we’re a good fit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Book"},"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns {"verticalAlignment":"top","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns are-vertically-aligned-top"><!-- wp:column {"width":"42%","verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:42%"><!-- wp:group {"style":{"spacing":{"blockGap":"1.1rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">What to expect</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"is-style-leaf-list"} -->
<ul class="wp-block-list is-style-leaf-list"><!-- wp:list-item -->
<li>A relaxed 15-minute conversation by phone or video</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Share as much or as little as you like</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Ask anything about how therapy works, fees or availability</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A real commitment to yourself: the first step toward the change you’re looking for</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:group {"className":"is-style-card-tint","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.75rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card-tint" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"fontSize":"large","level":3} -->
<h3 class="wp-block-heading has-large-font-size">Book online</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Choose a time for your free 15-minute consult in our secure booking system, Jane. You’ll get a confirmation by email.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://ownandbecome.janeapp.com">Book on Jane</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"own-and-become/crisis-notice"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"58%","verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:58%"><!-- wp:group {"className":"is-style-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.85rem"},"dimensions":{"minHeight":"100%"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-group is-style-card" style="min-height:100%;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Prefer to send a message?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"ob-hint","fontSize":"small","textColor":"muted"} -->
<p class="ob-hint has-muted-color has-text-color has-small-font-size">Please don’t include sensitive or detailed health information in this form. We’ll talk about the details together, privately. This form is for therapy enquiries only; we don’t accept sales or marketing pitches.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"ob-form","layout":{"type":"default"}} -->
<div class="wp-block-group ob-form"><!-- wp:shortcode -->
[contact-form-7 title="Own and Become contact form"]
<!-- /wp:shortcode --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
